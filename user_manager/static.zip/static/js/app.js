//  Show box onClick

$(document).ready(function() {

    // $("#table-reporting").hide();

    $(".table-link").click(function() {
        $("#table-reporting").show();
    });

});

// Add filter in table reporting model 
$(document).ready(function() {
    
    var max_fields = 5;
    var wrapper = $(".filter-table");
    var add_btn = $(".add-filter-table");

    var x = 1;

    $(add_btn).click(function(e) {
        e.preventDefault();

        if (x < max_fields) {
            x++;
            $(wrapper).append(
                '<div class="row added-filter-table">'
                
                    + '<div class="form-group col-md-3 mt-3"><label for="" class="">Champ</label><select class="w-100" id="select-1" name="name" id="" >'
                    
                    + '<option value="">-- Choisir le champ --</option><option value="">Champ 1</option><option value="">Champ 2</option></select></div>'
  
                    + '<div class="form-group col-md-3 mt-3"><label for="" class="">Filtre</label><select class="w-100" id="select-2" name="name" id="" ><option value="">-- Choisir le filtre --</option><option value="">-----------</option><option value="">-----------</option></select></div>'

                    + '<div class="form-group col-md-3 mt-3"><label for="" class="">Valeur</label><input type="number" class="w-100" id=""></div><div class="col-md-2 mt-3 pt-4"><a href="#" class="remove-filter-table"><i class="bi bi-trash mr-2"></i>Remove filter</a></div></div>'
            );
        }
    });

    $(wrapper).on("click", ".remove-filter-table", function(e) {
        e.preventDefault();
        $(this).parent().parent('.added-filter-table').remove();
        x--;
    });
} );

// Add filter in cell reporting model 
$(document).ready(function() {
    
    var max_fields = 5;
    var wrapper = $(".filter-cell");
    var add_btn = $(".add-filter-cell");

    var x = 1;

    $(add_btn).click(function(e) {
        e.preventDefault();

        if (x < max_fields) {
            x++;
            $(wrapper).append(
                '<div class="row added-filter-cell">'

                + '<div class="form-group col-md-3 mt-3"><label for="" class="">Champ</label><select class="w-100" id="select-1" name="name" id="" ><option value="">-- Choisir le champ --</option><option value="">Champ 1</option><option value="">Champ 2</option></select></div>'

               + '<div class="form-group col-md-3 mt-3"><label for="" class="">Filtre</label><select class="w-100" id="select-2" name="name" id="" ><option value="">-- Choisir le filtre --</option><option value="">-----------</option><option value="">-----------</option></select></div>'

               + '<div class="form-group col-md-3 mt-3"><label for="" class="">Variable</label><input type="number" class="w-100" id=""></div>'

               + '<div class="col-md-2 mt-3 pt-4"><a href="#" class="remove-filter-cell"><i class="bi bi-trash mr-2"></i>Remove filter</a></div>'            
      
                + '</div>'
            );
        }
    });

    $(wrapper).on("click", ".remove-filter-cell", function(e) {
        e.preventDefault();
        $(this).parent().parent('.added-filter-cell').remove();
        x--;
    });
} );

// DataTables initialization
$(document).ready(function() {
    $('#import-table').DataTable();
} );

$(document).ready(function() {
    $('#dpt-table').DataTable();
} );

$(document).ready(function() {
    $('#file-model-table').DataTable(
        {
            "scrollX": true
        }
    );
} );

// Show/Hide regex bloc onChange
$(document).ready(function() {
    $('#model-format').on('change', function() {
        $(".regex").hide();
        $("#" + $(this).val()).fadeIn(700);
    }).change();
});

// Add csv/excel regex bloc 
$(document).ready(function() {
    
    var max_fields = 3;
    var wrapper = $(".content");
    var add_csv_btn = $(".add-csv-regex");
    var add_excel_btn = $(".add-excel-regex");

    var x = 1;

    $(add_csv_btn).click(function(e) {
        e.preventDefault();

        if (x < max_fields) {
            x++;
            $(wrapper).append(
                '<fieldset class="added-csv-regex"><legend>Expression régulière format csv</legend><div class="divider"></div><div class="form-group mt-3"><label for="" class="">Expression</label><input type="name" class="w-100" name="name" id="" ></div>'
                +'<div class="form-group row d-flex justify-content-center mt-3"><div class="col-md-5 form-check"><input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"><label class="form-check-label mx-2" for="flexCheckDefault">regex-découpage</label></div>'

                +'<div class="col-md-5 form-check"><input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked><label class="form-check-label mx-2" for="flexCheckChecked">regex-extraction</label></div></div>'

                +'<div class="row"><div class="form-group col-md-6 mt-3"><label for="" class="">Lier à</label><select type="name" class="w-100" name="name" id="" ><option value="">-----------</option><option value="">-----------</option><option value="">-----------</option></select></div>'

                +'<div class="form-group col-md-6 mt-3"><label for="" class="">Table associée</label><select type="name" class="w-100" name="name" id="" ><option value="">-----------</option><option value="">-----------</option><option value="">-----------</option></select></div></div>'            
           
                +'<div class="form-group mt-3"><label for="" class="">Commentaire</label><textarea type="name" class="w-100" name="name" id="" ></textarea></div>'

                +'<div class="row line mb-4"><div class="form-group col-md-5 mt-3"><label for="" class="">Champ</label><select type="name" class="w-100" name="name" id="" ><option value="">-----------</option><option value="">txt - csv - rtf</option><option value="">excel</option></select></div>'
  
                +'<div class="form-group col-md-5 mt-3"><label for="" class="">Position</label><input type="number" class="w-100" name="name" id="" ></div>'

                +'<div class="col-md-2 mt-3 pt-4"><a href="#" class="add-line"><i class="bi bi-plus-circle-fill mr-2"></i>Add line</a></div></div>'

                +'<a href="#" class="remove-regex mt-5"><i class="bi bi-trash mr-2"></i>Remove box</a>'
            
                +'</fieldset>'
            );
        }
    });

    $(add_excel_btn).click(function(e) {
        e.preventDefault();

        if (x < max_fields) {
            x++;
            $(wrapper).append(

                '<fieldset class="added-excel-regex"><legend>Expression régulière format excel</legend><div class="divider"></div>'

                +'<div class="row"><div class="form-group col-md-4 mt-3"><label for="" class="">Colonne</label><input type="name" class="w-100" name="name" id="" ></div>'
                
                +'<div class="form-group col-md-8 mt-3"><label for="" class="">Expression</label><input type="name" class="w-100" name="name" id="" ></div></div>'
  
                +'<div class="form-group row d-flex justify-content-center mt-3"><div class="col-md-5 form-check"><input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"><label class="form-check-label mx-2" for="flexCheckDefault">regex-découpage</label></div>'

                +'<div class="col-md-5 form-check"><input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked><label class="form-check-label mx-2" for="flexCheckChecked">regex-extraction</label></div></div>'

                +'<div class="form-group mt-3"><label for="" class="">Table associée</label><select type="name" class="w-100" name="name" id="" ><option value="">-----------</option><option value="">-----------</option><option value="">-----------</option></select></div> '

                +'<div class="row line mb-4"><div class="form-group col-md-5 mt-3"><label for="" class="">Champ</label><select type="name" class="w-100" name="name" id="" ><option value="">-----------</option><option value="">txt - csv - rtf</option><option value="">excel</option></select></div>'
    
                    +'<div class="form-group col-md-5 mt-3"><label for="" class="">Position</label><input type="number" class="w-100" name="name" id="" ></div>'

                    +'<div class="col-md-2 mt-3 pt-4"><a href="#" class="add-line"><i class="bi bi-plus-circle-fill mr-2"></i>Add line</a></div>'   

                +'</div>'

                +'<a href="#" class="remove-regex mt-5"><i class="bi bi-trash mr-2"></i>Remove box</a>'

              +'</fieldset>'

            );
        }
    });

    $(wrapper).on("click", ".remove-regex", function(e) {
        e.preventDefault();
        $(this).parent('.added-csv-regex').remove();
        x--;
    });

    $(wrapper).on("click", ".remove-regex", function(e) {
        e.preventDefault();
        $(this).parent('.added-excel-regex').remove();
        x--;
    });

});

// Add regex line 
$(document).ready(function() {
    
    var max_fields = 5;
    var wrapper = $(".line");
    var add_btn = $(".add-line");

    var x = 1;

    $(add_btn).click(function(e) {
        e.preventDefault();

        if (x < max_fields) {
            x++;
            $(wrapper).append(
                '<div class="row added-line"><div class="form-group col-md-5 mt-3"><label for="" class="">Champ</label><select type="name" class="w-100" name="name" id="" ><option value="">-----------</option><option value="">-----------</option><option value="">-----------</option></select></div>'
  
                +'<div class="form-group col-md-5 mt-3"><label for="" class="">Position</label><input type="number" class="w-100" name="name" id="" ></div>'

                +'<div class="col-md-2 mt-3 pt-4"><a href="#" class="remove-line"><i class="bi bi-trash mr-2"></i></a></div></div>'
            );
        }
    });

    $(wrapper).on("click", ".remove-line", function(e) {
        e.preventDefault();
        $(this).parent().parent('.added-line').remove();
        x--;
    });

});

// Add Department 
$(document).ready(function() {
    
    var max_fields = 3;
    var wrapper = $(".line-dpt");
    var add_btn = $(".add-dpt");

    var x = 1;

    $(add_btn).click(function(e) {
        e.preventDefault();

        if (x < max_fields) {
            x++;
            $(wrapper).append(
                '<div class="row added-line-dpt"><div class="form-group col-md-6 mt-3"><label for="" class="">Département</label><input type="name" class="w-100" name="name" id="" ></div>'

                +'<div class="col-md-2 mt-3 pt-4"><a href="#" class="remove-dpt"><i class="bi bi-plus-circle-fill mr-2"></i>Remove Dpt</a></div></div>'

            );
        }
    });

    $(wrapper).on("click", ".remove-dpt", function(e) {
        e.preventDefault();
        $(this).parent().parent('.added-line-dpt').remove();
        x--;
    });

});
 
/**
 * Dropzone script
 */
Dropzone.autoDiscover = false;

var myDropzone = new Dropzone(".dropzone", {
    acceptedFiles: ".rtf, .csv, .txt, .xls, .xlsx, .docx, .docs, .doc",
    autoProcessQueue: false,
    parallelUploads: 4
});

document.querySelector("#upload-files").click(function() {
    myDropzone.processQueue();
});


/**
 * Filter script
 */

const transaction = {
    model: "transaction",
    fields: {
        card: "string",
        id: "int",
        debit: "float",
        agency: "relation"
    }
}
